export const environment = {
  production: true,
  host_url: 'https://tic-tac-toe-using-ai.herokuapp.com/'
};
